#!/c/Python25/python.exe

## Python path for EL2.1 2018:
#  /c/CCP4/Python2.7/python.exe
## Python path for EL2.1 2019:
#  /c/Python25/python.exe
## Python path for W414:
# /c/Python27/python.exe

print "* CHORISMATE MUTASE WITH CHORISMATE"
print "******"
print "* ATOMS IN QM-REGION ONLY"
print "* "
print "   24 "

n = 1

import sys

lines = open(sys.argv[1], "r").readlines()

for line in lines:
    words = line.split()

    if (len(words) > 3 and words[2] == "CHO"):
        print "%5d    1 %s" % (n, line[11:]),
        n = n + 1
